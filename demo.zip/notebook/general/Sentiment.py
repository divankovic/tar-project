import json
from string import punctuation

import tflearn
from nltk import WordNetLemmatizer, word_tokenize
from nltk.corpus import stopwords
from tflearn.data_utils import pad_sequences


class Sentiment:
    def __init__(self, path, dict_path):
        with open(dict_path, 'r') as io:
            self.word_dict = json.load(io)

        rnn = tflearn.input_data([None, 50])
        rnn = tflearn.embedding(rnn, input_dim=len(self.word_dict), output_dim=128)
        rnn = tflearn.lstm(rnn, 512, dropout=0.8, return_seq=True)
        rnn = tflearn.lstm(rnn, 512, dropout=0.8)
        rnn = tflearn.fully_connected(rnn, 2, activation='softmax')
        rnn = tflearn.regression(rnn, optimizer='adam', learning_rate=0.001, loss='categorical_crossentropy')

        self.model = tflearn.DNN(rnn, tensorboard_verbose=0)
        self.model.load(path)

    def classify(self, data):
        data = preprocess(data, self.word_dict)
        data = pad_sequences([data], maxlen=50, value=0.)
        return self.model.predict(data)[0][0]


def preprocess(data, word_dict):
    lemmatizer = WordNetLemmatizer()
    tokens = word_tokenize(data)
    tokens_filtered = [
        lemmatizer.lemmatize(token) for token in tokens
        if (token not in stopwords.words('english') and token not in punctuation)
    ]

    result = []
    for token in tokens_filtered:
        if token not in word_dict:
            code = 0
        else:
            code = word_dict[token]

        result.append(code)

    return result
