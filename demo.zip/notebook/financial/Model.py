import json
import pickle
import re
from string import punctuation

import nltk
from keras.models import load_model
from keras.preprocessing.sequence import pad_sequences
from nltk import WordNetLemmatizer, word_tokenize
from nltk.corpus import stopwords


class Model:

    def __init__(self, path, dict_path):
        self.max_len = 30
        self.model = self.model = load_model(path)

        with open(dict_path, 'rb') as handle:
            self.tokenizer = pickle.load(handle)

    def classify(self, data):
        data = preprocess_title(data, ner=True)
        data = [data]
        data = self.tokenizer.texts_to_sequences(data)
        data = pad_sequences(data, maxlen=self.max_len, value=0)
        return self.model.predict(data)[0][0]


def preprocess_title(title, ner=False):
    lemmatizer = WordNetLemmatizer()

    tokens = word_tokenize(title)
    if ner:
        tokens = ne_removal(tokens)

    filtered_tokens = [
        lemmatizer.lemmatize(token.lower()) for token in tokens
        if (token not in stopwords.words('english') and token not in punctuation)
    ]

    new_title = ''
    for token in filtered_tokens:
        new_title += token + ' '

    new_title.strip()

    return new_title


def ne_removal(tokens):
    ne_chunked = nltk.ne_chunk(nltk.pos_tag(tokens), binary=False)
    new_tokens = []
    for leaf in ne_chunked:
        if type(leaf) != nltk.Tree:
            new_tokens.append(leaf[0])

    regnumber = re.compile(r'\d+(?:,\d*)?')
    new_tokens = ['' if (regnumber.match(token) or token == '\'s') else token for token in new_tokens]
    return new_tokens


def load_test_data():
    dataset = {"titles": [], "companies": []}
    with open('./financial/headlines_test.json', 'r', encoding='utf-8') as io:
        data = json.load(io)
        for d in data:
            dataset["titles"].append(d["title"])
            dataset["companies"].append(d["company"])
    return dataset
